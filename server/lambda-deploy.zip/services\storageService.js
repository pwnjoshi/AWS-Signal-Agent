"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.storage = exports.StorageService = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const credential_providers_1 = require("@aws-sdk/credential-providers");
const DATA_DIR = process.env.AWS_LAMBDA_FUNCTION_NAME
    ? path_1.default.join('/tmp', 'data')
    : path_1.default.join(process.cwd(), 'data');
if (!fs_1.default.existsSync(DATA_DIR)) {
    try {
        fs_1.default.mkdirSync(DATA_DIR, { recursive: true });
    }
    catch (err) {
        console.warn('Warning creating data directory:', err);
    }
}
// Memory stores for local persistence
const FILES = {
    signals: path_1.default.join(DATA_DIR, 'signals.json'),
    topics: path_1.default.join(DATA_DIR, 'topics.json'),
    briefings: path_1.default.join(DATA_DIR, 'briefings.json'),
    preferences: path_1.default.join(DATA_DIR, 'preferences.json'),
    profiles: path_1.default.join(DATA_DIR, 'profiles.json'),
    logs: path_1.default.join(DATA_DIR, 'logs.json'),
};
const region = process.env.AWS_REGION || 'us-east-1';
const profile = process.env.AWS_PROFILE || 'cloudblueprint';
const ddbClient = new client_dynamodb_1.DynamoDBClient({
    region,
    ...(process.env.AWS_LAMBDA_FUNCTION_NAME ? {} : { credentials: (0, credential_providers_1.fromIni)({ profile }) })
});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(ddbClient);
function readJsonFile(filePath, fallback) {
    try {
        if (fs_1.default.existsSync(filePath)) {
            const data = fs_1.default.readFileSync(filePath, 'utf-8');
            return JSON.parse(data);
        }
    }
    catch (err) {
        console.error(`Error reading ${filePath}:`, err);
    }
    return fallback;
}
function writeJsonFile(filePath, data) {
    try {
        fs_1.default.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    }
    catch (err) {
        console.error(`Error writing ${filePath}:`, err);
    }
}
class StorageService {
    signals = new Map();
    topics = new Map();
    briefings = [];
    logs = [];
    preferences;
    activeProfile;
    constructor() {
        const savedSignals = readJsonFile(FILES.signals, []);
        savedSignals.forEach(s => this.signals.set(s.signal_id, s));
        const savedTopics = readJsonFile(FILES.topics, []);
        savedTopics.forEach(t => this.topics.set(t.topic_id, t));
        this.briefings = readJsonFile(FILES.briefings, []);
        this.logs = readJsonFile(FILES.logs, []);
        const loadedPrefs = readJsonFile(FILES.preferences, {});
        this.preferences = {
            user_id: 'usr_srijana_default',
            builder_id: loadedPrefs.builder_id || 'builder_srijana_2026',
            name: loadedPrefs.name || 'Srijana',
            email: loadedPrefs.email || 'srijana@builder.aws',
            email_list: loadedPrefs.email_list || (loadedPrefs.email ? [loadedPrefs.email] : ['srijana@builder.aws', 'devops@company.com']),
            email_enabled: loadedPrefs.email_enabled ?? true,
            digest_frequency: loadedPrefs.digest_frequency || 'daily',
            schedule_frequency: loadedPrefs.schedule_frequency || '6h',
            cron_expression: loadedPrefs.cron_expression || '0 */6 * * *',
            alert_threshold: loadedPrefs.alert_threshold || 'high',
            favorite_services: loadedPrefs.favorite_services || ['Amazon Bedrock', 'AWS Lambda', 'Amazon ECS'],
            favorite_topics: loadedPrefs.favorite_topics || ['Bedrock Latency', 'Cold Starts', 'Serverless Architecture'],
            last_visited_at: loadedPrefs.last_visited_at || new Date(Date.now() - 3600 * 1000 * 12).toISOString(),
        };
        this.activeProfile = {
            builder_id: this.preferences.builder_id,
            display_name: this.preferences.name,
            email: this.preferences.email,
            email_list: this.preferences.email_list,
            is_authenticated: true,
            logged_in_at: new Date().toISOString(),
        };
        this.hydrateFromDynamoDB();
    }
    async hydrateFromDynamoDB() {
        try {
            const sigScan = await docClient.send(new lib_dynamodb_1.ScanCommand({ TableName: 'AWSSignals' }));
            if (sigScan.Items && sigScan.Items.length > 0) {
                sigScan.Items.forEach(item => this.signals.set(item.signal_id, item));
            }
        }
        catch (err) {
            console.log(`[DynamoDB Hydrate] Note: ${err.message}. Using active in-memory and disk persistence.`);
        }
    }
    // Builder ID Authentication & Quick Login
    authenticateBuilderId(builderIdInput, name, email) {
        const cleanId = builderIdInput.trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '_') || 'builder_srijana_2026';
        const displayName = name || cleanId.replace('builder_', '').replace(/_/g, ' ').toUpperCase();
        const userEmail = email || `${cleanId.replace('builder_', '')}@builder.aws`;
        this.preferences.builder_id = cleanId;
        this.preferences.name = displayName;
        this.preferences.email = userEmail;
        if (!this.preferences.email_list.includes(userEmail)) {
            this.preferences.email_list.unshift(userEmail);
        }
        this.activeProfile = {
            builder_id: cleanId,
            display_name: displayName,
            email: userEmail,
            email_list: this.preferences.email_list,
            is_authenticated: true,
            logged_in_at: new Date().toISOString(),
        };
        writeJsonFile(FILES.preferences, this.preferences);
        writeJsonFile(FILES.profiles, this.activeProfile);
        return this.activeProfile;
    }
    getActiveProfile() {
        return this.activeProfile;
    }
    // Signals
    getSignals() {
        return Array.from(this.signals.values()).sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());
    }
    getSignalById(id) {
        return this.signals.get(id);
    }
    hasContentHash(hash) {
        return Array.from(this.signals.values()).some(s => s.content_hash === hash);
    }
    saveSignal(signal) {
        this.signals.set(signal.signal_id, signal);
        writeJsonFile(FILES.signals, Array.from(this.signals.values()));
        docClient.send(new lib_dynamodb_1.PutCommand({ TableName: 'AWSSignals', Item: signal })).catch(() => { });
    }
    toggleSaveSignal(id) {
        const sig = this.signals.get(id);
        if (sig) {
            sig.is_saved = !sig.is_saved;
            this.saveSignal(sig);
            return sig;
        }
        return undefined;
    }
    // Topics
    getTopics() {
        return Array.from(this.topics.values()).sort((a, b) => b.trend_score - a.trend_score);
    }
    saveTopics(topicsList) {
        topicsList.forEach(t => this.topics.set(t.topic_id, t));
        writeJsonFile(FILES.topics, Array.from(this.topics.values()));
        topicsList.forEach(t => {
            docClient.send(new lib_dynamodb_1.PutCommand({ TableName: 'AWSTopics', Item: t })).catch(() => { });
        });
    }
    // Daily Briefings
    getBriefings() {
        return this.briefings.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }
    getLatestBriefing() {
        return this.getBriefings()[0];
    }
    saveBriefing(briefing) {
        const idx = this.briefings.findIndex(b => b.date === briefing.date);
        if (idx >= 0) {
            this.briefings[idx] = briefing;
        }
        else {
            this.briefings.unshift(briefing);
        }
        writeJsonFile(FILES.briefings, this.briefings);
        docClient.send(new lib_dynamodb_1.PutCommand({ TableName: 'AWSBriefings', Item: briefing })).catch(() => { });
    }
    // User Preferences
    getPreferences() {
        return this.preferences;
    }
    updatePreferences(updates) {
        this.preferences = { ...this.preferences, ...updates };
        if (updates.email && (!this.preferences.email_list || !this.preferences.email_list.includes(updates.email))) {
            this.preferences.email_list = [updates.email, ...(this.preferences.email_list || []).filter(e => e !== updates.email)];
        }
        writeJsonFile(FILES.preferences, this.preferences);
        docClient.send(new lib_dynamodb_1.PutCommand({ TableName: 'AWSPreferences', Item: this.preferences })).catch(() => { });
        return this.preferences;
    }
    // Execution Logs
    getLogs() {
        return this.logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }
    saveLog(log) {
        this.logs.unshift(log);
        if (this.logs.length > 50)
            this.logs = this.logs.slice(0, 50);
        writeJsonFile(FILES.logs, this.logs);
        docClient.send(new lib_dynamodb_1.PutCommand({ TableName: 'AWSExecutionLogs', Item: log })).catch(() => { });
    }
    // "While You Were Away" summary metrics calculation
    getWhileYouWereAwaySummary() {
        const lastVisit = new Date(this.preferences.last_visited_at).getTime();
        const allSignals = this.getSignals();
        const newSinceVisit = allSignals.filter(s => new Date(s.discovered_at).getTime() >= lastVisit);
        const activeSignals = newSinceVisit.length > 0
            ? newSinceVisit
            : allSignals.filter(s => new Date(s.discovered_at).getTime() >= Date.now() - 86400000 * 2);
        const announcements = activeSignals.filter(s => s.category === 'Announcement').length;
        const discussions = activeSignals.filter(s => s.category === 'Community Discussion').length;
        const alerts = activeSignals.filter(s => s.signal_score >= 80).length;
        return {
            last_visited_at: this.preferences.last_visited_at,
            new_announcements: Math.max(3, announcements),
            community_discussions: Math.max(7, discussions),
            emerging_signals: 2,
            high_priority_alerts: Math.max(1, alerts),
            signals: activeSignals,
        };
    }
}
exports.StorageService = StorageService;
exports.storage = new StorageService();
