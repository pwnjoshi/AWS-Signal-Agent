"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const storageService_1 = require("../services/storageService");
const agentScheduler_1 = require("../scheduler/agentScheduler");
const emailAlertService_1 = require("../services/emailAlertService");
const briefingGenerator_1 = require("../services/briefingGenerator");
const security_1 = require("../middleware/security");
const awsFeedsCollector_1 = require("../collectors/awsFeedsCollector");
const pollyService_1 = require("../services/pollyService");
const bedrockService_1 = require("../services/bedrockService");
const builderCenterService_1 = require("../services/builderCenterService");
const router = (0, express_1.Router)();
// Real-time Grounded QA with Dori & Amazon Bedrock
router.post('/dori/ask', (0, security_1.rateLimiter)(60, 15 * 60 * 1000), async (req, res) => {
    try {
        const { question, history, synthesizeAudio = true } = req.body;
        if (!question || typeof question !== 'string') {
            return res.status(400).json({ error: 'question string is required' });
        }
        const signals = storageService_1.storage.getSignals();
        const topics = storageService_1.storage.getTopics();
        const { answer, relevantSignals } = await (0, bedrockService_1.askDoriQuestion)(question, signals, topics, history);
        let audioBase64;
        if (synthesizeAudio) {
            const pollyRes = await (0, pollyService_1.synthesizeDoriSpeech)(answer, 'Ivy', 'neural');
            if (pollyRes) {
                audioBase64 = pollyRes.audioBase64;
            }
        }
        res.json({
            success: true,
            answer,
            relevantSignals,
            audioBase64,
        });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// Amazon Polly Generative & Neural Speech Endpoint for Dori
router.post('/dori/synthesize', (0, security_1.rateLimiter)(60, 15 * 60 * 1000), async (req, res) => {
    try {
        const { text, voiceId, engine } = req.body;
        if (!text || typeof text !== 'string') {
            return res.status(400).json({ error: 'text string is required' });
        }
        const result = await (0, pollyService_1.synthesizeDoriSpeech)(text, voiceId || 'Ruth', engine || 'generative');
        if (!result) {
            return res.status(500).json({ error: 'Speech synthesis failed' });
        }
        res.json({ success: true, ...result });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// Decoupled Public API v1 endpoints (open for external applications to fetch AWS news)
router.get('/v1/news', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), async (req, res) => {
    try {
        const { items, errors } = await (0, awsFeedsCollector_1.fetchAWSFeeds)();
        res.json({
            status: 'success',
            count: items.length,
            errors: errors.length > 0 ? errors : undefined,
            news: items,
        });
    }
    catch (err) {
        res.status(500).json({ status: 'error', error: err.message });
    }
});
router.get('/v1/signals', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    const signals = storageService_1.storage.getSignals();
    res.json({ status: 'success', count: signals.length, signals });
});
router.get('/v1/briefings/latest', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    let latest = storageService_1.storage.getLatestBriefing();
    if (!latest) {
        latest = (0, briefingGenerator_1.generateDailyBriefing)(storageService_1.storage.getSignals());
        storageService_1.storage.saveBriefing(latest);
    }
    res.json({ status: 'success', briefing: latest });
});
router.get('/v1/trends', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    res.json({ status: 'success', trends: storageService_1.storage.getTopics() });
});
// Builder ID Quick Auth & Profile Endpoints with AWS Builder Center Verification
router.post('/auth/builder-id', (0, security_1.rateLimiter)(30, 15 * 60 * 1000), async (req, res) => {
    const { builder_id, display_name, email } = req.body;
    if (!builder_id || typeof builder_id !== 'string') {
        return res.status(400).json({ error: 'builder_id is required' });
    }
    // Verify against AWS Builder Center Directory
    const verification = await (0, builderCenterService_1.verifyWithAWSBuilderCenter)(builder_id, display_name, email);
    if (!verification.verified) {
        return res.status(400).json({
            error: verification.error || `Username '${builder_id}' could not be verified in AWS Builder Center.`
        });
    }
    const profile = storageService_1.storage.authenticateBuilderId(verification.builder_id, verification.display_name, verification.email);
    res.json({ success: true, profile, verification });
});
router.get('/auth/profile', (req, res) => {
    res.json(storageService_1.storage.getActiveProfile());
});
// Security Guard Middleware across core API routes
router.use(security_1.apiSecurityGuard);
// Agent Status & Telemetry
router.get('/agent/status', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    const status = (0, agentScheduler_1.getSchedulerStatus)();
    const logs = storageService_1.storage.getLogs();
    res.json({
        status: 'ONLINE',
        is_running: status.is_running,
        cron_expression: status.cron_expression,
        next_scheduled_run: status.next_scheduled_run,
        latest_run: status.last_log,
        execution_history: logs,
    });
});
// Bedrock Execution Trigger
router.post('/agent/run', (0, security_1.rateLimiter)(10, 15 * 60 * 1000), async (req, res) => {
    try {
        const log = await (0, agentScheduler_1.runAgentPipeline)('manual_demo');
        res.json({ success: true, log });
    }
    catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});
// Signals
router.get('/signals', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    const { search, service, category, minImportance, source, sort, savedOnly } = req.query;
    let signals = storageService_1.storage.getSignals();
    if (search) {
        const q = search.toLowerCase();
        signals = signals.filter(s => s.title.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q) || s.aws_services.some(srv => srv.toLowerCase().includes(q)));
    }
    if (service) {
        signals = signals.filter(s => s.aws_services.includes(service));
    }
    if (category) {
        signals = signals.filter(s => s.category === category);
    }
    if (source) {
        signals = signals.filter(s => s.source === source);
    }
    if (minImportance) {
        const min = parseInt(minImportance, 10);
        signals = signals.filter(s => s.importance_score >= min);
    }
    if (savedOnly === 'true') {
        signals = signals.filter(s => s.is_saved);
    }
    if (sort === 'importance') {
        signals.sort((a, b) => b.importance_score - a.importance_score);
    }
    else if (sort === 'relevance') {
        signals.sort((a, b) => b.relevance_score - a.relevance_score);
    }
    else if (sort === 'score') {
        signals.sort((a, b) => b.signal_score - a.signal_score);
    }
    else {
        signals.sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());
    }
    res.json({ count: signals.length, signals });
});
router.get('/signals/:id', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    const signal = storageService_1.storage.getSignalById(req.params.id);
    if (!signal) {
        return res.status(404).json({ error: 'Signal not found' });
    }
    res.json(signal);
});
router.post('/signals/:id/toggle-save', (0, security_1.rateLimiter)(50, 15 * 60 * 1000), (req, res) => {
    const updated = storageService_1.storage.toggleSaveSignal(req.params.id);
    if (!updated) {
        return res.status(404).json({ error: 'Signal not found' });
    }
    res.json(updated);
});
// Daily Briefings
router.get('/briefings', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    res.json(storageService_1.storage.getBriefings());
});
router.get('/briefings/latest', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    let latest = storageService_1.storage.getLatestBriefing();
    if (!latest) {
        const signals = storageService_1.storage.getSignals();
        latest = (0, briefingGenerator_1.generateDailyBriefing)(signals);
        storageService_1.storage.saveBriefing(latest);
    }
    res.json(latest);
});
// Trends
router.get('/trends', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    res.json(storageService_1.storage.getTopics());
});
// Services Explorer Data
router.get('/services', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    const signals = storageService_1.storage.getSignals();
    const serviceCounts = {};
    for (const sig of signals) {
        for (const srv of sig.aws_services) {
            if (!serviceCounts[srv]) {
                serviceCounts[srv] = { count: 0, signals: [], avgScore: 0 };
            }
            serviceCounts[srv].count++;
            serviceCounts[srv].signals.push(sig);
        }
    }
    const result = Object.entries(serviceCounts).map(([name, data]) => {
        const totalScore = data.signals.reduce((acc, curr) => acc + curr.signal_score, 0);
        return {
            service_name: name,
            signal_count: data.count,
            avg_signal_score: Math.round(totalScore / data.count),
            recent_signals: data.signals.slice(0, 5),
        };
    }).sort((a, b) => b.signal_count - a.signal_count);
    res.json(result);
});
// "While You Were Away" summary
router.get('/summary/while-you-were-away', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    const summary = storageService_1.storage.getWhileYouWereAwaySummary();
    res.json(summary);
});
// Preferences
router.get('/preferences', (0, security_1.rateLimiter)(100, 15 * 60 * 1000), (req, res) => {
    res.json(storageService_1.storage.getPreferences());
});
router.put('/preferences', (0, security_1.rateLimiter)(30, 15 * 60 * 1000), (req, res) => {
    const updated = storageService_1.storage.updatePreferences(req.body);
    if (updated.cron_expression) {
        (0, agentScheduler_1.updateScheduleCron)(updated.cron_expression);
    }
    res.json(updated);
});
// Test Email Alert
router.post('/alerts/test', (0, security_1.rateLimiter)(5, 15 * 60 * 1000), async (req, res) => {
    const signals = storageService_1.storage.getSignals();
    const targetSignal = signals[0];
    const prefs = storageService_1.storage.getPreferences();
    if (!targetSignal) {
        return res.status(400).json({ error: 'No signals available for test alert' });
    }
    const result = await (0, emailAlertService_1.sendSignalAlertIfNeeded)(targetSignal, prefs);
    res.json({ success: true, result });
});
exports.default = router;
