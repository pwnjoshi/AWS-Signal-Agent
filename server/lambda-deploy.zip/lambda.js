"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const serverless_http_1 = __importDefault(require("serverless-http"));
const routes_1 = __importDefault(require("./api/routes"));
const app = (0, express_1.default)();
// Only use Express cors middleware when running locally
// In AWS Lambda, Lambda Function URL native CORS handles headers at the gateway layer to avoid duplicate headers
if (!process.env.AWS_LAMBDA_FUNCTION_NAME) {
    app.use((0, cors_1.default)({
        origin: '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept'],
    }));
}
app.use(express_1.default.json());
app.get('/', (req, res) => {
    res.json({
        status: 'ONLINE',
        service: 'AWS Signal Autonomous Intelligence Agent',
        briefings_url: '/api/briefings/latest',
        signals_url: '/api/signals',
        timestamp: new Date().toISOString()
    });
});
app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'AWS Signal Agent Lambda', timestamp: new Date().toISOString() });
});
app.use('/api', routes_1.default);
exports.handler = (0, serverless_http_1.default)(app);
