"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const routes_1 = __importDefault(require("./api/routes"));
const agentScheduler_1 = require("./scheduler/agentScheduler");
dotenv_1.default.config();
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3001;
app.use((0, cors_1.default)());
app.use(express_1.default.json());
// API Prefix
app.use('/api', routes_1.default);
// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'AWS Signal Agent', timestamp: new Date().toISOString() });
});
// Start Express server and initialize background scheduler
app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`  🚀 AWS Signal Autonomous Intelligence Agent Server  `);
    console.log(`  Listening on http://localhost:${PORT}`);
    console.log(`  Mode: ${process.env.NODE_ENV || 'development'}`);
    console.log(`=======================================================`);
    // Initialize scheduler
    (0, agentScheduler_1.initScheduler)();
});
