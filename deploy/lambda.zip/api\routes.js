"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const storageService_1 = require("../services/storageService");
const agentScheduler_1 = require("../scheduler/agentScheduler");
const emailAlertService_1 = require("../services/emailAlertService");
const router = (0, express_1.Router)();
// Agent Status & Telemetry
router.get('/agent/status', (req, res) => {
    const status = (0, agentScheduler_1.getSchedulerStatus)();
    const logs = storageService_1.storage.getLogs();
    res.json({
        status: 'ONLINE',
        is_running: status.is_running,
        next_scheduled_run: status.next_scheduled_run,
        latest_run: status.last_log,
        execution_history: logs,
    });
});
router.post('/agent/run', async (req, res) => {
    try {
        const log = await (0, agentScheduler_1.runAgentPipeline)('manual_demo');
        res.json({ success: true, log });
    }
    catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});
// Signals
router.get('/signals', (req, res) => {
    const { search, service, category, minImportance, source, sort, savedOnly } = req.query;
    let signals = storageService_1.storage.getSignals();
    if (search) {
        const q = search.toLowerCase();
        signals = signals.filter(s => s.title.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q) || s.aws_services.some(srv => srv.toLowerCase().includes(q)));
    }
    if (service) {
        signals = signals.filter(s => s.aws_services.includes(service));
    }
    if (category) {
        signals = signals.filter(s => s.category === category);
    }
    if (source) {
        signals = signals.filter(s => s.source === source);
    }
    if (minImportance) {
        const min = parseInt(minImportance, 10);
        signals = signals.filter(s => s.importance_score >= min);
    }
    if (savedOnly === 'true') {
        signals = signals.filter(s => s.is_saved);
    }
    // Sorting
    if (sort === 'importance') {
        signals.sort((a, b) => b.importance_score - a.importance_score);
    }
    else if (sort === 'relevance') {
        signals.sort((a, b) => b.relevance_score - a.relevance_score);
    }
    else if (sort === 'score') {
        signals.sort((a, b) => b.signal_score - a.signal_score);
    }
    else {
        // default newest
        signals.sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());
    }
    res.json({ count: signals.length, signals });
});
router.get('/signals/:id', (req, res) => {
    const signal = storageService_1.storage.getSignalById(req.params.id);
    if (!signal) {
        return res.status(404).json({ error: 'Signal not found' });
    }
    res.json(signal);
});
router.post('/signals/:id/toggle-save', (req, res) => {
    const updated = storageService_1.storage.toggleSaveSignal(req.params.id);
    if (!updated) {
        return res.status(404).json({ error: 'Signal not found' });
    }
    res.json(updated);
});
// Daily Briefings
router.get('/briefings', (req, res) => {
    res.json(storageService_1.storage.getBriefings());
});
router.get('/briefings/latest', (req, res) => {
    const latest = storageService_1.storage.getLatestBriefing();
    if (!latest) {
        return res.status(404).json({ error: 'No briefings generated yet' });
    }
    res.json(latest);
});
// Trends
router.get('/trends', (req, res) => {
    res.json(storageService_1.storage.getTopics());
});
// Services Explorer Data
router.get('/services', (req, res) => {
    const signals = storageService_1.storage.getSignals();
    const serviceCounts = {};
    for (const sig of signals) {
        for (const srv of sig.aws_services) {
            if (!serviceCounts[srv]) {
                serviceCounts[srv] = { count: 0, signals: [], avgScore: 0 };
            }
            serviceCounts[srv].count++;
            serviceCounts[srv].signals.push(sig);
        }
    }
    const result = Object.entries(serviceCounts).map(([name, data]) => {
        const totalScore = data.signals.reduce((acc, curr) => acc + curr.signal_score, 0);
        return {
            service_name: name,
            signal_count: data.count,
            avg_signal_score: Math.round(totalScore / data.count),
            recent_signals: data.signals.slice(0, 5),
        };
    }).sort((a, b) => b.signal_count - a.signal_count);
    res.json(result);
});
// "While You Were Away" summary
router.get('/summary/while-you-were-away', (req, res) => {
    const summary = storageService_1.storage.getWhileYouWereAwaySummary();
    res.json(summary);
});
// Preferences
router.get('/preferences', (req, res) => {
    res.json(storageService_1.storage.getPreferences());
});
router.put('/preferences', (req, res) => {
    const updated = storageService_1.storage.updatePreferences(req.body);
    res.json(updated);
});
// Test Email Alert
router.post('/alerts/test', async (req, res) => {
    const signals = storageService_1.storage.getSignals();
    const targetSignal = signals[0];
    const prefs = storageService_1.storage.getPreferences();
    if (!targetSignal) {
        return res.status(400).json({ error: 'No signals available for test alert' });
    }
    const result = await (0, emailAlertService_1.sendSignalAlertIfNeeded)(targetSignal, prefs);
    res.json({ success: true, result });
});
exports.default = router;
